# App-specific Source

This contains AX5043 specific files

Put any .h or .c files (besides main.c) you want to compile with your app in here. They will automatically build when you run make.

If you don't want them to build, move them to another directory or the app's top level directory to effectively "disable" them.
